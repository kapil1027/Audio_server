import datetime, os, traceback, mutagen, re
from flask import Flask, request, render_template,Response
from werkzeug.utils import secure_filename
import mysql.connector
from werkzeug.exceptions import HTTPException


app = Flask(__name__, static_url_path="/static")

UPLOAD_FOLDER = r'./upload'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.secret_key="svsVbsRVsRgvac#$%37hNBE$56HY%&^*I$Gsdrf31rdfetg23r$%UJ$E%#465#46#%HGr"

def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'mp3', 'wav'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS



mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  database="audio_test"
)

mycursor = mydb.cursor()


x=["""CREATE TABLE IF NOT EXISTS song (
    ID int NOT NULL AUTO_INCREMENT UNIQUE,
    songName varchar(100) NOT NULL,
    duration int NOT NULL,
    File_path nvarchar(100) NOT NULL,
    uploaded TIMESTAMP
    );""",

    """CREATE TABLE IF NOT EXISTS podcast (
    ID int NOT NULL AUTO_INCREMENT UNIQUE,
    podcastName varchar(100) NOT NULL,
    podcastDuration int NOT NULL,
    podcastHost varchar(100) NOT NULL,
    podcastParticipants varchar(100) NOT NULL,
    File_path nvarchar(100) NOT NULL,
    uploaded TIMESTAMP
    );""",

    """CREATE TABLE IF NOT EXISTS audiobook (
    ID int NOT NULL AUTO_INCREMENT UNIQUE,
    bookTitle varchar(100) NOT NULL,
    author varchar(100) NOT NULL,
    narrator varchar(100) NOT NULL,
    duration int NOT NULL,
    File_path nvarchar(100) NOT NULL,
    uploaded TIMESTAMP
    );""" ]


for i in x:
    mycursor.execute(i)
    mydb.commit()
mycursor.close()


class SQL_Process():
        
    def sql_execute(self,sql_cmd):
        try:
            cur = mydb.cursor()
            cur.execute(sql_cmd)
            if "SELECT" in sql_cmd:
                x_ = dict(); x_in = dict()
                k=0
                for i in cur:
                    x_in = dict()
                    for j in range(len(i)):
                        x_in[cur.description[j][0]] = i[j]
                    x_[k] = x_in
                    k+=1
                return x_
            mydb.commit()
            cur.close()
        except:
            return Response("BAD REQUEST",status=400, mimetype='application/json')
        return Response("OK",status=200, mimetype='application/json')
    
    def sql_delete(self,a_type,id_):
        sql_cmd = 'SELECT File_path FROM {} WHERE ID={}'.format( a_type , id_)
        cur = mydb.cursor(buffered=True)
        cur.execute(sql_cmd)
        if cur:
            for i in cur:
                if os.path.exists(i[0]):
                    os.remove(i[0])
        try:
            x= 'DELETE FROM {} WHERE ID={}'.format(a_type,id_)
            cur.execute(x)
            mydb.commit()
            if cur.rowcount == 0:
                raise Exception("no data")
            cur.close()
        except:
            cur.close()
            return Response("BAD REQUEST",status=400, mimetype='application/json')
        return Response("OK",status=200, mimetype='application/json')


class data_process():
    
    def  __init__(self):
        self.song_data='songName,File_path,duration'
        self.audiobook_data='bookTitle,author,narrator,File_path,duration'
        self.podcast_data='podcastName,podcastHost,podcastParticipants,File_path,podcastDuration'
        
    def check_info(self,request,path):
        try:
            table = request["audio_type"]
            if request["audio_type"] == "song":
                data = "'{}','{}'".format(request["songName"],
                                          path)
                sql_cmd = 'INSERT INTO song ({}) VALUES ({},'.format(self.song_data,data)
                
            elif request["audio_type"] == "audiobook":
                data ="'{}','{}','{}','{}'".format(request["bookTitle"], 
                                                   request["author"], 
                                                   request["narrator"], 
                                                   path)
                sql_cmd = 'INSERT INTO audiobook ({}) VALUES ({},'.format(self.audiobook_data ,data)
                
            elif request["audio_type"] == "podcast":
                data ="'{}','{}','{}','{}'".format(request["podcastName"], 
                                                   request["podcastHost"], 
                                                   request["podcastParticipants"], 
                                                   path)
                sql_cmd = 'INSERT INTO podcast ({}) VALUES ({},'.format(self.podcast_data,data)
            else:
                return 500
        except:
            return 500
        return sql_cmd
    
    def update_info(self,request,path,audioFileID):
        try:
            table = request["audio_type"]
            if request["audio_type"] == "song":
                sql_cmd = 'UPDATE song SET songName="{}",File_path="{}",duration=000 WHERE ID={}'.format(request["songName"],
                                                                                                    path,
                                                                                                    audioFileID)
            elif request["audio_type"] == "audiobook":
                sql_cmd = 'UPDATE audiobook SET bookTitle="{}",author="{}",narrator="{}",File_path="{}",duration=000 WHERE ID={}'.format(request["bookTitle"],
                                                                                                                        request["author"],
                                                                                                                        request["narrator"],
                                                                                                                       path,
                                                                                                                       audioFileID)
            elif request["audio_type"] == "podcast":
                sql_cmd = 'UPDATE podcast SET podcastName="{}",podcastHost="{}",podcastParticipants="{}",File_path="{}",podcastDuration=000 WHERE ID={}'.format(request["podcastName"],
                                                                                                                                               request["podcastHost"],
                                                                                                                                               request["podcastParticipants"],
                                                                                                                                               path,
                                                                                                                                              audioFileID)
            else:
                return 400
        except:
            return 400
        return sql_cmd


Pclass = data_process()
SQLclass = SQL_Process()


@app.route('/<audioFileType>/<audioFileID>', methods=['PUT'])
def update(audioFileType,audioFileID):
    if request.method == 'PUT':
        data_form = {}
        result = request.form
        if 'audio' not in request.files:
            return Response("BAD REQUEST",status=400, mimetype='application/json')
        for k,i in result.items():
            data_form[str(k)] = str(i)
        file = request.files['audio']
        filename = secure_filename(file.filename)
        bar1 = datetime.datetime.now().strftime("[%d-%m-%Y_%H.%M.%S]")
        filename = os.path.join(app.config['UPLOAD_FOLDER'], str(bar1 + filename))
        filename=re.sub(r'\\',"/",filename)
        reply = Pclass.update_info(data_form , filename, audioFileID)
        if reply != 400:
            if file and allowed_file(file.filename):
                file.save(filename)
                audio_length = mutagen.File(filename).info.pprint().split(",")[-1].strip().split(" ")[0]
                reply = reply.replace("000",str(audio_length))
                return SQLclass.sql_execute(reply)
            else:
                return Response("BAD REQUEST",status=400, mimetype='application/json')
        return Response("BAD REQUEST",status=400, mimetype='application/json')
    return Response("BAD REQUEST",status=400, mimetype='application/json')



@app.route('/', methods=['POST'])
def create():
    if request.method == 'POST':
        data_form = {}
        result = request.form
        if 'audio' not in request.files:
            return Response("BAD REQUEST",status=400, mimetype='application/json')
        for k,i in result.items():
            data_form[str(k)] = str(i)
        file = request.files['audio']
        filename = secure_filename(file.filename)
        bar1 = datetime.datetime.now().strftime("[%d-%m-%Y_%H.%M.%S]")
        filename = os.path.join(app.config['UPLOAD_FOLDER'], str(bar1 + filename))
        filename=re.sub(r'\\',"/",filename)
        reply = Pclass.check_info(data_form , filename)
        if reply != 400:
            if file and allowed_file(file.filename):
                file.save(filename)
                audio_length = mutagen.File(filename).info.pprint().split(",")[-1].strip().split(" ")[0]
                reply = reply+str(audio_length)+ ")"
                return SQLclass.sql_execute(reply)
            else:
                return Response("Internal Server ERROR",status=500, mimetype='application/json')
        return Response("Internal Server ERROR",status=500, mimetype='application/json')
    return Response("BAD REQUEST",status=400, mimetype='application/json')



@app.route('/<audioFileType>/<audioFileID>', methods=['DELETE'])
def delete(audioFileType,audioFileID):
    if request.method == 'DELETE':
        return SQLclass.sql_delete(audioFileType,audioFileID)
    return Response("BAD REQUEST",status=400, mimetype='application/json')



@app.route('/<audioFileType>/<audioFileID>', methods=['GET'])
def details1(audioFileType,audioFileID):
    if request.method == 'GET':
        sql = 'SELECT * from {} WHERE ID={}'.format(audioFileType,audioFileID)
        return SQLclass.sql_execute(sql)
    return Response("BAD REQUEST",status=400, mimetype='application/json')


@app.route('/<audioFileType>', methods=['GET'])
def details2(audioFileType):
    if request.method == 'GET':
        sql = 'SELECT * from {}'.format(audioFileType)
        return SQLclass.sql_execute(sql)
    return Response("BAD REQUEST",status=400, mimetype='application/json')





@app.errorhandler(HTTPException)
def page_not_found(e):
    return Response("Internal Server ERROR",status=500, mimetype='application/json')



if __name__ == '__main__':
    app.run( port=5000 )
